//
//  ViewController.swift
//  Apple pie
//
//  Created by Alumno on 28/02/24.
//

import UIKit

class ViewController: UIViewController {
    
   var listOfWords = ["corsario","swift","glosario","incandescente","insecto","programa"]
    
    let incorrectmovesallowed = 7
    
    var totalwins = 0 {
        didSet{
            newRound()
        }
    }
    var totalLoses = 0 {
        didSet{
            newRound()
        }
    }

    @IBOutlet weak var treeimageview: UIImageView!
    
    @IBOutlet weak var correctwordlabel: UILabel!
    
    
    @IBOutlet weak var scorelabel: UILabel!
    
    @IBOutlet var letterbuttons: [UIButton]!
    
    @IBAction func letterbuttonpressed(_ sender: UIButton) {
        sender.isEnabled = false
        let letterString = sender.configuration!.title!
        let letter = Character(letterString.lowercased())
        currentGame.playerGuessed(letter: letter)
        UpdateGameState()
  
    }
    func UpdateGameState(){
        if currentGame.incorrectMovesRemaining == 0 {
            totalLoses += 1
          } else if currentGame.word == currentGame.formattedWord {
            totalwins += 1
          } else {
            updateUI()
          }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newRound()
        // Do any additional setup after loading the view.
    }
    var currentGame: Game!
    
    func enableLetterButtons(_ enable: Bool){
        for button in letterbuttons {
            button.isEnabled = enable
        }
    }
    
    func newRound() {
        
        if !listOfWords.isEmpty{
            let newWord = listOfWords.removeFirst()
            currentGame = Game(word: newWord,
            incorrectMovesRemaining: incorrectmovesallowed,
            guessedLetters: [])
            enableLetterButtons(true)
            updateUI()
        }else{
            enableLetterButtons(false)
        }
    }
    func updateUI() {
        var letters = [String]()
            for letter in currentGame.formattedWord {
                letters.append(String(letter))
            }
            let wordWithSpacing = letters.joined(separator: " ")

        correctwordlabel.text = wordWithSpacing
        scorelabel.text = "wins: \(totalwins), losses: \(totalLoses)"
        treeimageview.image = UIImage(named: "Tree \(currentGame.incorrectMovesRemaining)")
    }

}

